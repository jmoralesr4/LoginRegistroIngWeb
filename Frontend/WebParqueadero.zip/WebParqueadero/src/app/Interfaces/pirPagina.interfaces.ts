
export interface InfoPiePagina {
  Empresa?: string;
  Logo?: string;
  Email?: string;
}
