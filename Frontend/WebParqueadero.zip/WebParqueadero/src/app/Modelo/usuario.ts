// export interface Usuario {
//     Cedula: number;
//     Nombre: string;
//     Apellido: string;
//     email: string;
//     Telefono: string;
//     TipoVehiculo: string;
//     Placa: string;
//     Perfil: string;
//     Usuario: string;
//     Contrasena: string;
//     Estado: string;
//     TipoDocumento: string;
// }

export interface Usuario {
    Cedula: number;
  Nombre: string;
  Apellido: string;
  email: string;
  Telefono?: any;
  TipoVehiculo: string;
  Placa?: any;
  Perfil?: any;
  Usuario1: string;
  Contrasena: string;
  Estado: string;
  TipoDocumento: string;
}
